<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, POST");
//header('Access-Control-Max-Age: 86400');
header('content-type: application/json; charset=utf-8');

require_once("../config/config.php");
require_once('../lang/' . strtolower(SITE_LANG) . '/rs_lang.website.php');
$objCommon 				= new Common;
$objMontvirouser 		= new Montvirouser;
$objMontviroProerty 	= new Montviroproperty;
$objMontviroProertyPD 	= new Montviroproperty;
$objMontviroProertyLegd	= new Montviroaccount;
$objMontviroapplication	= new Montviroapplication;
$objMontviroCustomer	= new Montviroapplication;
$objMontviroPaymentOvVi = new Montviroapplication;
$objValidate 			= new Validate;
$objBF 					= new Crypt_Blowfish('CBC');
$objBF->setKey($cipher_key);
$PropertyObj 			= array();
//echo EncData('mode_3', 2, $objBF);
//die();
$RequestedMethord = trim(DecData($_GET["mode"], 1, $objBF));
	
if($RequestedMethord == 'mode_1'){
// User Login API
////////////////////////////////////////////////////////////////////
/******************************************************************/
////////////////////////////////////////////////////////////////////

	$user_mobile	 		= trim($_GET["user_mobile"]);
	$user_pass	 			= trim($_GET["user_pass"]);

	$objValidate->setArray($_GET);
	$objValidate->setCheckField("user_mobile", _VLD_INVALID_Mobile, "S");
	$objValidate->setCheckField("user_pass", _VLD_PASSWORD, "S");
	$vResult = $objValidate->doValidate();
	// See if any error are not returned
	if(!$vResult){
		$objMontvirouser->resetProperty();
		$objMontvirouser->setProperty("user_mobile", $user_mobile);
		$objMontvirouser->setProperty("user_pass", $objBF->encrypt($user_pass, ENCRYPTION_KEY));
		$objMontvirouser->setProperty("login_required", 1);
		$objMontvirouser->setProperty("user_type_id", 4);
		$objMontvirouser->checkUserLogin();
		if($objMontvirouser->totalRecords() >= 1){
			$rows = $objMontvirouser->dbFetchArray(1);
			if($rows['isActive'] != 1){
				$vResult['invalid_login'] = _CUST_ACCOUNT_SUSPENDED;
				echo json_encode($vResult);
			}
			else{
				$CreateAccessToken = EncData($rows['user_id'].'-'.$rows['user_mobile'], 1, $objBF);
				$PropertyObj[] = array("login_validation" => "true", "acc_token" => $CreateAccessToken, "fullname" => $rows['fullname'], "profile_img" => USER_PROFILE_URL.$rows['user_profile_img'], "user_designation" => $rows['user_designation']);
				echo json_encode($PropertyObj);
			}
		}
		else{
				$PropertyObj[] = array("login_validation" => "false", "acc_token" => '', "invalid_login" => _LOGIN_INVALID_LOGIN);
				echo json_encode($PropertyObj);
		}
	} else {
		echo json_encode($vResult);
	}

////////////////////////////////////////////////////////////////////
/******************************************************************/
////////////////////////////////////////////////////////////////////
// Get Floor List
} elseif($RequestedMethord == 'mode_2'){ 
	
	$Property_id 		= $_GET["prop_reg_id"];
	
	$objValidate->setArray($_GET);
	$objValidate->setCheckField("prop_reg_id", 'Project Type id missing.', "S");
	$vResult = $objValidate->doValidate();
	// See if any error are not returned
	if(!$vResult){
		$objMontviroProerty->resetProperty();
		$objMontviroProerty->setProperty("isNot", 3);
		$objMontviroProerty->setProperty("project_id", $Property_id);
		$objMontviroProerty->setProperty("ORDERBY", 'propety_floor_id');
		$objMontviroProerty->lstPropertyFloorPlan();
		while($ListOfFloorPlan = $objMontviroProerty->dbFetchArray(1)){
		$PropertyObj[] = array("f_id" => $ListOfFloorPlan["propety_floor_id"], "floor_name" =>$ListOfFloorPlan["floor_name"]);
		}
		echo json_encode($PropertyObj);
	} else {
		echo json_encode($vResult);
	}
	
} elseif($RequestedMethord == 'mode_3'){
// Get List of Properties
	
	$Property_id 		= trim($_GET["prop_reg_id"]);
	$Floor_id 			= trim($_GET["f_id"]);
	
	$objValidate->setArray($_GET);
	$objValidate->setCheckField("prop_reg_id", 'Project Type id missing.', "S");
	$objValidate->setCheckField("f_id", 'Floor id missing.', "S");
	$vResult = $objValidate->doValidate();
	// See if any error are not returned
	if(!$vResult){
		$objMontviroProerty->resetProperty();
		$objMontviroProerty->setProperty("property_registered_id", $Property_id);
		$objMontviroProerty->setProperty("propety_floor_id", $Floor_id);
		$objMontviroProerty->setProperty("ORDERBY", 'property_id');
		$objMontviroProerty->lstProperties();
		while($ListOfProperties = $objMontviroProerty->dbFetchArray(1)){
				
					$objMontviroapplication->setProperty("property_id", $ListOfProperties["property_id"]);
					$objMontviroapplication->lstApplication();
					$CountApplications = $objMontviroapplication->totalRecords();
					if($CountApplications > 0){
						$ApplicationDetail = $objMontviroapplication->dbFetchArray(1);
							$objMontviroCustomer->setProperty("customer_id", $ApplicationDetail["customer_id"]);
							//$objMontviroCustomer->setProperty("customer_type", 1);
							$objMontviroCustomer->lstApplicationCustomer();
							$AplicCustomerDetail = $objMontviroCustomer->dbFetchArray(1);
						
						//$objMontviroapplication->resetProperty();
						$objMontviroPaymentOvVi->setProperty("aplic_id", $ApplicationDetail["aplic_id"]);
						$objMontviroPaymentOvVi->lstPaymentOverview();
						$AplicPaymentOverView = $objMontviroPaymentOvVi->dbFetchArray(1);
						
						//$objMontvirouser->resetProperty();
						$objMontvirouser->setProperty("user_id", $ApplicationDetail["seller_agent_id"]);
						$objMontvirouser->lstUsers();
						$SellerAgentDetail = $objMontvirouser->dbFetchArray(1);
					}

					$objMontviroProertyPD->setProperty("property_id", $ListOfProperties["property_id"]);
					$objMontviroProertyPD->setProperty("isActive", 1);
					$objMontviroProertyPD->lstPropertyPaymentDetail();
					$PropertyPaymentDetail = $objMontviroProertyPD->dbFetchArray(1);
					
					$objMontviroProertyLegd->setProperty("property_id", $ListOfProperties["property_id"]);
					$objMontviroProertyLegd->VwPropertyVsLedger();
					$property_vs_ledger = $objMontviroProertyLegd->dbFetchArray(1);
					if($CountApplications > 0){
					$PropertyObj[] = array(
					"property_id" => $ListOfProperties["property_id"], 
					"floor_name" =>$ListOfProperties["floor_name"], 
					"property_section" =>$ListOfProperties["property_section"],
					"property_area" =>$ListOfProperties["property_area"],
					"property_image" => COMPANY_PROP_THUMB_URL.$ListOfProperties["property_image"],
					"property_number" =>$ListOfProperties["property_number"],
					"property_img_title" =>$ListOfProperties["property_img_title"],
					"property_img_cord" =>$ListOfProperties["property_img_cord"],
					"poperty_img_shap" =>$ListOfProperties["poperty_img_shap"],
					"property_status" =>$ListOfProperties["property_status"],
					"prop_status" => PropertyStatus($ListOfProperties["property_status"]),
					"book_duration" =>$ListOfProperties["book_duration"],
					"property_desc" =>$ListOfProperties["property_desc"],
					"reg_number" =>$ApplicationDetail["reg_number"],
					"payment_mode" => ApplicationPaymentMode($AplicPaymentOverView["payment_mode"]),
					"total_amount_received" =>$property_vs_ledger["total_amount_received"],
					"customer_id" =>$ApplicationDetail["customer_id"],
					"customer_fname" =>$AplicCustomerDetail["customer_fname"],
					"customer_lname" =>$AplicCustomerDetail["customer_lname"],
					"customer_of" =>$AplicCustomerDetail["customer_of"],
					"customer_father" =>$AplicCustomerDetail["customer_father"],
					"customer_email" =>$AplicCustomerDetail["customer_email"],
					"customer_cnic" =>$AplicCustomerDetail["customer_cnic"],
					"customer_mobile" =>$AplicCustomerDetail["customer_mobile"],
					"down_payment" =>$PropertyPaymentDetail["down_payment"],
					"instalment_per_month" =>$PropertyPaymentDetail["instalment_per_month"],
					"rate_per_sq_ft" =>$PropertyPaymentDetail["rate_per_sq_ft"],
					"property_rent_sqft" =>$ListOfProperties["property_rent_sqft"],
					"seller_agent_name" =>$SellerAgentDetail["fullname"]
					);
					//$objMontviroapplication->resetProperty();
					} else {
					$PropertyObj[] = array(
					"property_id" => $ListOfProperties["property_id"], 
					"floor_name" =>$ListOfProperties["floor_name"], 
					"property_section" =>$ListOfProperties["property_section"],
					"property_area" =>$ListOfProperties["property_area"],
					"property_image" => COMPANY_PROP_THUMB_URL.$ListOfProperties["property_image"],
					"property_number" =>$ListOfProperties["property_number"],
					"property_img_title" =>$ListOfProperties["property_img_title"],
					"property_img_cord" =>$ListOfProperties["property_img_cord"],
					"poperty_img_shap" =>$ListOfProperties["poperty_img_shap"],
					"property_status" =>$ListOfProperties["property_status"],
					"prop_status" => PropertyStatus($ListOfProperties["property_status"]),
					"book_duration" =>$ListOfProperties["book_duration"],
					"property_desc" =>$ListOfProperties["property_desc"],
					"reg_number" =>$ApplicationDetail["reg_number"],
					"payment_mode" => ApplicationPaymentMode($AplicPaymentOverView["payment_mode"]),
					"total_amount_received" =>$property_vs_ledger["total_amount_received"],
					"down_payment" =>$PropertyPaymentDetail["down_payment"],
					"instalment_per_month" =>$PropertyPaymentDetail["instalment_per_month"],
					"rate_per_sq_ft" =>$PropertyPaymentDetail["rate_per_sq_ft"],
					"property_rent_sqft" =>$ListOfProperties["property_rent_sqft"]
					);	
					}
		}
		echo json_encode($PropertyObj);
	} else {
		echo json_encode($vResult);
	}

} elseif($RequestedMethord == 'mode_4'){
// Get List of Lock Properties Agent Base
	
	$acc_token		= trim($_GET["acc_token"]);

	$objValidate->setArray($_GET);
	$objValidate->setCheckField("acc_token", 'Access Token is missing.', "S");
	$vResult = $objValidate->doValidate();
	// See if any error are not returned
	if(!$vResult){
		list($UserId,$UserMobileNumber)= explode('-', trim(DecData($acc_token, 1, $objBF)));
		$objMontviroProerty->resetProperty();
		$objMontviroProerty->setProperty("user_id", $UserId);
		$objMontviroProerty->setProperty("ORDERBY", 'temp_lock_id');
		$objMontviroProerty->lstPropertyTempLock();
		if($objMontviroProerty->totalRecords() > 0){
			while($ListOfProperties = $objMontviroProerty->dbFetchArray(1)){
				$PropertyObj[] = array(
						"temp_lock_id" => $ListOfProperties["temp_lock_id"], 
						"property_id" =>$ListOfProperties["property_id"], 
						"customer_fname" =>$ListOfProperties["customer_fname"],
						"customer_lname" =>$ListOfProperties["customer_lname"],
						"customer_father" =>$ListOfProperties["customer_father"],
						"customer_email" =>$ListOfProperties["customer_email"],
						"customer_c_address" =>$ListOfProperties["customer_c_address"],
						"customer_mobile" =>$ListOfProperties["customer_mobile"],
						"received_amount" =>$ListOfProperties["received_amount"],
						"till_lock_duration" =>$ListOfProperties["till_lock_duration"],
						"lock_status" => TempLockedStatus($ListOfProperties["lock_status"])
						);
			}
		} else {
			$PropertyObj[] = array("return" => 'No record found.');
		}
		echo json_encode($PropertyObj);
	} else {
		echo json_encode($vResult);
	}

} elseif($RequestedMethord == 'mode_5'){
	//prop_id 
	$prop_id 		= trim($_GET["prop_id"]);
	
	$objValidate->setArray($_GET);
	$objValidate->setCheckField("prop_id", 'Property id missing.', "S");
	$vResult = $objValidate->doValidate();
	// See if any error are not returned
	if(!$vResult){
		$objMontviroProerty->resetProperty();
		$objMontviroProerty->setProperty("property_id", $prop_id);
		$objMontviroProerty->lstProperties();
		while($ListOfProperties = $objMontviroProerty->dbFetchArray(1)){
					$objMontviroProertyPD->setProperty("property_id", $ListOfProperties["property_id"]);
					$objMontviroProertyPD->setProperty("isActive", 1);
					$objMontviroProertyPD->lstPropertyPaymentDetail();
					$PropertyPaymentDetail = $objMontviroProertyPD->dbFetchArray(1);
					
					$PropertyObj[] = array(
					"property_id" => $ListOfProperties["property_id"], 
					"floor_name" =>$ListOfProperties["floor_name"], 
					"property_section" =>$ListOfProperties["property_section"],
					"property_area" =>$ListOfProperties["property_area"],
					"property_image" =>$ListOfProperties["property_image"],
					"property_number" =>$ListOfProperties["property_number"],
					"property_img_title" =>$ListOfProperties["property_img_title"],
					"property_img_cord" =>$ListOfProperties["property_img_cord"],
					"poperty_img_shap" =>$ListOfProperties["poperty_img_shap"],
					"property_status" =>$ListOfProperties["property_status"],
					"prop_status" => PropertyStatus($ListOfProperties["property_status"]),
					"book_duration" =>$ListOfProperties["book_duration"],
					"property_desc" =>$ListOfProperties["property_desc"],
					"down_payment" =>$PropertyPaymentDetail["down_payment"],
					"instalment_per_month" =>$PropertyPaymentDetail["instalment_per_month"],
					"rate_per_sq_ft" =>$PropertyPaymentDetail["rate_per_sq_ft"],
					"property_rent_sqft" =>$ListOfProperties["property_rent_sqft"]
					);
		}
		echo json_encode($PropertyObj);
	} else {
		echo json_encode($vResult);
	}

	
} elseif($RequestedMethord == 'mode_6'){
	// Post Property Lock 
	$acc_token				= trim($_GET["acc_token"]);
	$property_id			= trim($_GET["prop_id"]);
	$customer_fname			= trim($_GET['customer_fname']);
	$customer_lname			= trim($_GET['customer_lname']);
	$customer_father		= trim($_GET['customer_father']);
	$customer_cnic			= trim($_GET['customer_cnic']);
	$customer_passport		= trim($_GET['customer_passport']);
	$customer_email			= trim($_GET['customer_email']);
	$customer_c_address		= trim($_GET['customer_c_address']);
	$customer_p_address		= trim($_GET['customer_p_address']);
	$customer_phone			= trim($_GET['customer_phone']);
	$customer_mobile		= trim($_GET['customer_mobile']);
	$customer_mobile_2		= trim($_GET['customer_mobile_2']);
	$received_amount		= trim($_GET['received_amount']);
	$till_lock_duration		= trim($_GET["till_lock_duration"]);
	$customer_old_id		= trim($_GET["customer_old_id"]);
	$isActive				= 1;
	$reg_date				= date('Y-m-d H:i:s');
	
	$objValidate->setArray($_GET);
	$objValidate->setCheckField("acc_token", 'Access Token' . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("prop_id", 'Property ID' . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("customer_fname", _REG_FIRST_NAME . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("customer_lname", _REG_LAST_NAME . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("customer_cnic", _REG_CNIC . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("customer_father", 'Father name' . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("customer_mobile", _REG_MOBILE . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("customer_c_address", 'Customer current address' . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("customer_p_address", 'Customer permanent address' . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("customer_phone", 'Customer phone' . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("till_lock_duration", 'Lock duration' . _IS_REQUIRED_FLD, "S");
	$objValidate->setCheckField("received_amount", 'Token amount' . _IS_REQUIRED_FLD, "S");
	
	$vResult = $objValidate->doValidate();
	// See if any error are not returned
	if(!$vResult){
		
		list($UserId,$UserMobileNumber)= explode('-', trim(DecData($acc_token, 1, $objBF)));
		$objMontviroProerty->resetProperty();
		$temp_lock_id = $objMontviroProerty->genCode("rs_tbl_property_temp_lock", "temp_lock_id");
		$objMontviroProerty->resetProperty();
		$objMontviroProerty->setProperty("temp_lock_id", $temp_lock_id);
		$objMontviroProerty->setProperty("property_id", $property_id);
		$objMontviroProerty->setProperty("user_id", trim($UserId));
		
		$objMontviroProerty->setProperty("customer_old_id", $customer_old_id);
		$objMontviroProerty->setProperty("customer_fname", $customer_fname);
		$objMontviroProerty->setProperty("customer_lname", $customer_lname);
		$objMontviroProerty->setProperty("customer_father", $customer_father);
		$objMontviroProerty->setProperty("customer_cnic", $customer_cnic);
		$objMontviroProerty->setProperty("customer_passport", $customer_passport);
		$objMontviroProerty->setProperty("customer_email", $customer_email);
		$objMontviroProerty->setProperty("customer_c_address", $customer_c_address);
		$objMontviroProerty->setProperty("customer_p_address", $customer_p_address);
		$objMontviroProerty->setProperty("customer_phone", $customer_phone);
		$objMontviroProerty->setProperty("customer_mobile", $customer_mobile);
		$objMontviroProerty->setProperty("customer_mobile_2", $customer_mobile_2);
		$objMontviroProerty->setProperty("received_amount", $received_amount);
		$objMontviroProerty->setProperty("till_lock_duration", date('Y-m-d', strtotime(date("Y-m-d"). ' + '.$till_lock_duration.' days')));
		$objMontviroProerty->setProperty("lock_status", 5);
		$objMontviroProerty->setProperty("entery_date", date('Y-m-d H:i:s'));
		if($objMontviroProerty->actPropertyTempLock("I")){
		
			$objMontviroProerty->resetProperty();
			$objMontviroProerty->setProperty("property_id", $property_id);
			$objMontviroProerty->setProperty("user_id", trim($UserId));
			$objMontviroProerty->setProperty("property_status", 6);
			$objMontviroProerty->setProperty("book_duration", $till_lock_duration);
			$objMontviroProerty->actProperties("U");
			
				$objMontviroProerty->resetProperty();
				$objMontviroProerty->setProperty("property_id", $property_id);
				$objMontviroProerty->setProperty("user_id", trim($UserId));
				$objMontviroProerty->setProperty("entery_date", date('Y-m-d H:i:s'));
				$objMontviroProerty->setProperty("log_desc", "Agent has been locked this property for next ".$till_lock_duration." Day's");
				$objMontviroProerty->setProperty("isActive", 1);
				$objMontviroProerty->actPropertyLog("I");
				
				$PropertyObj[] = array("msg" => _LOCKED_PROPERTY_MSG_SUCCESS, "lock_prop_id" => $$temp_lock_id);
				echo json_encode($vResult);
		}
	} else {
		echo json_encode($vResult);
	}
} elseif($RequestedMethord == 'mode_7'){
	//Check Customer Record.
	$GetCustomerCnic = trim($_GET["customer_cnic"]);
	$objMontviroapplication->resetProperty();
	$objMontviroapplication->setProperty("customer_cnic", $GetCustomerCnic);
	$objMontviroapplication->lstApplicationCustomer();
	if($objMontviroapplication->totalRecords() > 0){
	$data = $objMontviroapplication->dbFetchArray(1);
	$PropertyObj[] = array("customer_old_id" => $rows["customer_id"], "customer_fname" => $rows['customer_fname'], "customer_lname" => $rows['customer_lname'], "customer_of" => $rows['customer_of'], "customer_father" => $rows['customer_father'], "customer_email" => $rows['customer_email'], "customer_cnic" => $rows['customer_cnic'], "customer_passport" => $rows['customer_passport'], "customer_c_address" => $rows['customer_c_address'], "customer_p_address" => $rows['customer_p_address'], "customer_phone" => $rows['customer_phone'], "customer_mobile" => $rows['customer_mobile'], "customer_mobile_2" => $rows['customer_mobile_2']);
	echo json_encode($PropertyObj);
	} else {
	$PropertyObj[] = array("msg" => 'No record found.');
	}
} elseif($RequestedMethord == 'mode_8'){
	
} else {
	$PropertyObj[] = array("mode" => 'mode id missing.');
	echo json_encode($PropertyObj);
}